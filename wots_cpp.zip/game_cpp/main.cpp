

#include "../framework/engine.hpp"


int main()
{
	engine::run();
	return 0;
}
